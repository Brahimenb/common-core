/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line copy.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: benbiki <benbiki@student.1337.ma>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/11/19 14:36:22 by benbiki           #+#    #+#             */
/*   Updated: 2026/11/19 19:24:25 by benbiki          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

int	update_stash(char **stash, size_t line_len)
{
	size_t	len;
	char	*new_stash;

	len = ft_strlen(*stash);
	if (len > line_len)
	{
		new_stash = ft_strdup(*stash + line_len);
		if (!new_stash)
			return (-1);
		free(*stash);
		*stash = new_stash;
	}
	else
	{
		free(*stash);
		*stash = NULL;
	}
	return (1);
}

char	*extract_line(char *stash)
{
	char	*newline;
	char	*line;
	size_t	line_len;
	size_t	i;

	newline = ft_strchr(stash, '\n');
	if (newline)
		line_len = (newline - stash) + 1;
	else
		line_len = ft_strlen(stash);
	line = malloc(line_len + 1);
	if (!line)
		return (NULL);
	i = 0;
	while (i < line_len)
	{
		line[i] = stash[i];
		i++;
	}
	line[i] = '\0';
	return (line);
}

int	read_and_store(int fd, char **stash)
{
	char	*buffer;
	char	*newline;
	ssize_t	bytes_read;
	int		result;

	if (BUFFER_SIZE <= 0)
		return (-1);
	buffer = malloc((size_t)BUFFER_SIZE + 1);
	if (!buffer)
		return (-1);
	result = 1;
	newline = ft_strchr(*stash, '\n');
	while (!newline)
	{
		bytes_read = read(fd, buffer, BUFFER_SIZE);
		if (bytes_read <= 0)
		{
			result = (int)bytes_read;
			break ;
		}
		if (append_buffer(buffer, bytes_read, stash) == -1)
		{
			result = -1;
			break ;
		}
		newline = ft_strchr(*stash, '\n');
	}
	free(buffer);
	return (result);
}

static char	*free_stash(char **stash)
{
	free(*stash);
	*stash = NULL;
	return (NULL);
}

char	*get_next_line(int fd)
{
	static char	*stash;
	char		*line;
	int			status;

	if (!stash)
	{
		stash = ft_strdup("");
		if (!stash)
			return (NULL);
	}
	status = read_and_store(fd, &stash);
	if (status == -1 || !*stash)
		return (free_stash(&stash));
	line = extract_line(stash);
	if (!line)
		return (free_stash(&stash));
	if (update_stash(&stash, ft_strlen(line)) == -1)
	{
		free(line);
		return (free_stash(&stash));
	}
	return (line);
}
